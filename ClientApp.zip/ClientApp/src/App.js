import React from 'react';

import AppRouter from './routes/routes';

import './custom.css';

const App = () => {
    return (
        <AppRouter />
    );
};

export default App;