﻿import React from "react";

const HomePage = () => {
    return (
        <div>
            <h1>HELLO</h1>
        </div>
    );
};

export default HomePage;